Object.defineProperty(exports, "__esModule", {
  value: true
});

require('ant-design-vue/dist/antd.css');

require('leaflet/dist/leaflet.css');

require('@supermapgis/vue-iclient-leaflet/static/libs/iclient-leaflet/iclient-leaflet.min.css');

require('@supermapgis/vue-iclient-leaflet/dist/iclient-leaflet-vue.css');

var iclient = require('@supermapgis/vue-iclient-leaflet/dist/iclient-leaflet-vue');

exports.default = iclient;
